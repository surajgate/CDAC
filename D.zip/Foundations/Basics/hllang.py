upper = int(input('Upper Limit: '))
total = upper * (upper + 1) / 2
print('Sum of Integers =', int(total))
print('Goodbye User.')


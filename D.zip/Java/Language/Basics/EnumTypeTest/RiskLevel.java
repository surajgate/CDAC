enum RiskLevel {
	NONE, LOW, HIGH;
}

